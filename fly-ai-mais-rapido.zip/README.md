# Fly AI

Primeira versão da aplicação Fly AI. Requer Node.js 18 ou mais recente; não precisa instalar pacotes.

## Abrir localmente

1. Abra um terminal nesta pasta.
2. Execute `npm start`.
3. Abra `http://localhost:3000` no navegador.

O histórico e as preferências ficam no armazenamento local do navegador e não sincronizam entre dispositivos.

## Conectar à NVIDIA NIM

Os modos estão configurados para usar endpoints de desenvolvimento gratuitos da NVIDIA:

- Rápido: `nvidia/nemotron-3.5-lightning-30b-a3b`
- Pro: `nvidia/nemotron-3.5-super-vl-120b-a12b`

Para ativar as respostas, crie/consulte sua chave em [NVIDIA Build](https://build.nvidia.com/). O servidor aceita `NVIDIA_API_KEY` no `.env` ou lê a chave do arquivo local `NVIDIA_KEY_APi.env/Novo Documento de Texto.txt` (pode conter apenas a chave ou uma linha `NVIDIA_API_KEY=...`). O caminho pode ser alterado com `NVIDIA_API_KEY_FILE`. Reinicie o servidor depois de salvar. **Não coloque a chave em `app.js`, no navegador, nem publique o arquivo de chave no GitHub.** O `.gitignore` exclui `.env` e a pasta da chave.

Ambos os modelos constam com endpoint gratuito ativo no catálogo da NVIDIA. Os endpoints de desenvolvimento têm limites e podem mudar de disponibilidade. Confira a conta NVIDIA para ver seus limites atuais; para uso público, todos os visitantes compartilhariam a cota da chave do servidor. Não envie dados pessoais ou confidenciais sem revisar as condições do endpoint.

## Recursos disponíveis

- Conversas locais persistentes, nova conversa e remoção do histórico.
- Dois modos de seleção; cada um envia o modo correspondente ao backend e usa seu identificador configurado.
- Tema claro/escuro/automático e preferência local.
- Ditado pelo reconhecimento de fala do navegador, quando disponível.
- Leitura das respostas com voz do navegador.
- Anexo preparado; análise de imagem e geração de imagem ainda dependem da integração com um provedor de visão/imagem e permanecem desativadas. Não há conta, sincronização, geração de imagem ou conversa de voz em tempo real nesta versão.

## Notas da revisão

- O servidor limita 20 mensagens por minuto por IP (ajuste em `rateLimit`, no `server.js`). Atrás de proxy, todos os visitantes podem aparecer com o mesmo IP.
- O Fly AI usa um prompt de sistema em português; mude com `FLY_SYSTEM_PROMPT` no `.env`.
- Se uma resposta der "modelo não encontrado", confira `FLY_MODEL_FAST` / `FLY_MODEL_PRO` no `.env` e o nome exato do modelo em [build.nvidia.com](https://build.nvidia.com/).
- Conversas longas enviam apenas as últimas 30 mensagens ao provedor.
- O modo Rápido usa `nvidia/nemotron-3.5-lightning-30b-a3b`, desativa o raciocínio para respostas diretas e limita a saída a 512 tokens por padrão (`FLY_MAX_TOKENS_FAST`). O modo Pro usa `nvidia/nemotron-3.5-super-vl-120b-a12b`, mantém o raciocínio ativado e limita a saída a 4096 tokens (`FLY_MAX_TOKENS_PRO`). As respostas aparecem progressivamente enquanto chegam. O tempo limite continua por inatividade (`FLY_IDLE_TIMEOUT_MS`, padrão 90s sem receber dados) com teto total (`FLY_TIMEOUT_MS`, padrão 300s).
