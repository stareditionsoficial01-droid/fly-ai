const $ = s => document.querySelector(s);
const storeKey = 'flyai.conversations.v1';
const prefsKey = 'flyai.preferences.v1';
let conversations = read(storeKey, []), prefs = read(prefsKey, {theme:'light', mode:'fast'}), activeId = null, mode = prefs.mode || 'fast', busy = false, recognition = null;
const conversation = $('#conversation'), welcome = $('#welcome'), messagesEl = $('#messages'), input = $('#promptInput');
function read(k, fallback){try{return JSON.parse(localStorage.getItem(k)) ?? fallback}catch{return fallback}}
function persist(){try{localStorage.setItem(storeKey, JSON.stringify(conversations))}catch{toast('Não foi possível salvar o histórico neste navegador.')}renderHistory()}
function uid(){return crypto.randomUUID?crypto.randomUUID():Date.now().toString(36)+Math.random().toString(36).slice(2)}
function current(){return conversations.find(c=>c.id===activeId)}
function setTheme(theme){prefs.theme=theme;document.body.classList.toggle('dark',theme==='dark'||(theme==='system'&&matchMedia('(prefers-color-scheme: dark)').matches));try{localStorage.setItem(prefsKey,JSON.stringify(prefs))}catch{}$('#themeSelect').value=theme;document.querySelector('meta[name=theme-color]').content=document.body.classList.contains('dark')?'#15171b':'#f8f9fb'}
function setMode(m){mode=m;$('#modeLabel').innerHTML=m==='pro'?'Fly AI 2.1 <b>Pro</b>':'Fly AI 1.5 <b>Rápido</b>';document.querySelectorAll('.mode-option').forEach(b=>b.classList.toggle('selected',b.dataset.mode===m));$('#modeMenu').classList.add('hidden')}
function renderHistory(){const list=$('#historyList');list.innerHTML='';[...conversations].reverse().forEach(c=>{const b=document.createElement('button');b.className='history-item'+(c.id===activeId?' active':'');b.innerHTML='<span>◷</span><span class="history-title"></span>';b.querySelector('.history-title').textContent=c.title;b.onclick=()=>openConversation(c.id);list.append(b)})}
function showWelcome(){welcome.classList.remove('hidden');messagesEl.classList.add('hidden');messagesEl.innerHTML='';activeId=null;renderHistory()}
function openConversation(id){activeId=id;welcome.classList.add('hidden');messagesEl.classList.remove('hidden');messagesEl.innerHTML='';const c=current();if(c){c.messages.forEach(m=>drawMessage(m));if(c.mode)setMode(c.mode)}renderHistory();scrollBottom()}
function newConversation(){activeId=null;mode=prefs.mode||'fast';setMode(mode);showWelcome();input.focus();closeSidebar()}
function drawMessage(m){const row=document.createElement('div');row.className='message '+m.role; if(m.role==='assistant'){const mark=document.createElement('span');mark.className='message-mark';mark.textContent='✦';row.append(mark)}const body=document.createElement('div');body.className='message-body';body.textContent=m.content;row.append(body);if(m.role==='assistant'&&!m.pending){const actions=document.createElement('div');actions.className='message-actions';const copy=document.createElement('button');copy.textContent='Copiar';copy.onclick=()=>{(navigator.clipboard?navigator.clipboard.writeText(m.content):Promise.reject()).then(()=>toast('Resposta copiada.'),()=>toast('Não foi possível copiar neste navegador.'))};const speak=document.createElement('button');speak.textContent='Ouvir';speak.onclick=()=>speakText(m.content);actions.append(copy,speak);body.append(actions)}messagesEl.append(row);return row}
function scrollBottom(){requestAnimationFrame(()=>conversation.scrollTop=conversation.scrollHeight)}
function toast(msg){const t=$('#toast');t.textContent=msg;t.classList.remove('hidden');clearTimeout(toast.timer);toast.timer=setTimeout(()=>t.classList.add('hidden'),3200)}
async function send(text=input.value.trim()) {if(!text||busy)return;let c=current();if(!c){c={id:uid(),title:text.slice(0,38)+(text.length>38?'…':''),messages:[],mode};conversations.push(c);activeId=c.id}c.mode=mode;c.messages.push({role:'user',content:text,mode});input.value='';resizeInput();welcome.classList.add('hidden');messagesEl.classList.remove('hidden');drawMessage({role:'user',content:text});const pending=drawMessage({role:'assistant',content:'',pending:true});pending.querySelector('.message-body').innerHTML='<span class="typing-dots"><i></i><i></i><i></i></span>';busy=true;$('#sendBtn').disabled=true;scrollBottom();persist();
  try {
    const res = await fetch('/api/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ mode, messages: c.messages.filter(m => !m.error).slice(-30).map(({ role, content }) => ({ role, content })) }) });
    if (!res.ok) { const data = await res.json().catch(() => ({})); throw Error(data.error || 'Não foi possível obter uma resposta.'); }
    if (!(res.headers.get('content-type') || '').includes('text/event-stream')) throw Error('O servidor não enviou a resposta em streaming. Reinicie o Fly AI.');
    const reader = res.body.getReader(), decoder = new TextDecoder(), body = pending.querySelector('.message-body');
    let buffer = '', answer = '', responseModel = '';
    const consume = block => {
      const dataLine = block.split('\n').find(line => line.startsWith('data:'));
      if (!dataLine) return;
      const event = JSON.parse(dataLine.slice(5).trim());
      if (event.error) throw Error(event.error);
      if (event.token) { answer += event.token; body.textContent = answer; scrollBottom(); }
      if (event.done) responseModel = event.model || '';
    };
    while (true) {
      const { value, done } = await reader.read();
      buffer += decoder.decode(value || new Uint8Array(), { stream: !done }).replace(/\r\n/g, '\n');
      let boundary;
      while ((boundary = buffer.indexOf('\n\n')) >= 0) { consume(buffer.slice(0, boundary)); buffer = buffer.slice(boundary + 2); }
      if (done) { if (buffer.trim()) consume(buffer); break; }
    }
    if (!answer) throw Error('O provedor respondeu sem conteúdo.');
    pending.remove(); c.messages.push({ role: 'assistant', content: answer, mode, model: responseModel });
    if (activeId === c.id) drawMessage({ role: 'assistant', content: answer }); persist();
  }
  catch(e){pending.remove();const explanation=e.message.includes('Failed to fetch')?'Não consegui falar com o servidor. Confira se o Fly AI está aberto pelo endereço local.':e.message;c.messages.push({role:'assistant',content:explanation,mode,error:true});if(activeId===c.id)drawMessage({role:'assistant',content:explanation});persist()}
  finally{busy=false;$('#sendBtn').disabled=false;if(activeId===c.id){input.focus();scrollBottom()}}}
function resizeInput(){input.style.height='auto';input.style.height=Math.min(input.scrollHeight,150)+'px'}
function closeSidebar(){$('#sidebar').classList.remove('open');$('#overlay').classList.add('hidden')}
function speakText(text){if(!('speechSynthesis'in window)){toast('Leitura por voz indisponível neste navegador.');return}speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.lang='pt-BR';speechSynthesis.speak(u)}
$('#sendBtn').onclick=()=>send();input.addEventListener('input',resizeInput);input.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing){e.preventDefault();send()}});
$('#newChat').onclick=newConversation;$('#modeTrigger').onclick=()=>$('#modeMenu').classList.toggle('hidden');document.querySelectorAll('.mode-option').forEach(b=>b.onclick=()=>{mode=b.dataset.mode;setMode(mode);prefs.mode=mode;localStorage.setItem(prefsKey,JSON.stringify(prefs))});$('#themeToggle').onclick=()=>setTheme(document.body.classList.contains('dark')?'light':'dark');
document.querySelectorAll('.suggestion').forEach(b=>b.onclick=()=>send(b.dataset.prompt));$('#collapse').onclick=()=>$('#sidebar').classList.toggle('collapsed');$('#mobileMenu').onclick=()=>{$('#sidebar').classList.add('open');$('#overlay').classList.remove('hidden')};$('#overlay').onclick=closeSidebar;
$('#settingsBtn').onclick=()=>{$('#themeSelect').value=prefs.theme||'light';$('#prefMode').value=prefs.mode||'fast';$('#settingsDialog').showModal()};$('#closeSettings').onclick=$('#doneSettings').onclick=()=>$('#settingsDialog').close();$('#themeSelect').onchange=e=>setTheme(e.target.value);$('#prefMode').onchange=e=>{prefs.mode=e.target.value;localStorage.setItem(prefsKey,JSON.stringify(prefs))};$('#deleteAll').onclick=()=>{if(confirm('Apagar todas as conversas salvas neste dispositivo?')){conversations=[];persist();newConversation();$('#settingsDialog').close();toast('Histórico local apagado.')}};$('#clearHistory').onclick=()=>{if(conversations.length&&confirm('Apagar todas as conversas salvas neste dispositivo?')){conversations=[];persist();showWelcome()}};
$('#attachBtn').onclick=()=>$('#imageInput').click();$('#imageInput').onchange=e=>{if(e.target.files.length)toast('Análise de imagem precisa de um provedor com visão conectado. Nenhuma imagem foi enviada.');e.target.value=''};
$('#micBtn').onclick=()=>{const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR){toast('Ditado não está disponível neste navegador.');return}if(recognition){recognition.stop();recognition=null;return}recognition=new SR();recognition.lang='pt-BR';recognition.interimResults=false;recognition.onresult=e=>{input.value+=(input.value?' ':'')+e.results[0][0].transcript;resizeInput();input.focus()};recognition.onerror=()=>toast('Não foi possível usar o microfone. Confira a permissão do navegador.');recognition.onend=()=>recognition=null;recognition.start();toast('Ouvindo… fale sua mensagem.')};
setTheme(prefs.theme||'light');setMode(mode);renderHistory();
if(conversations.length){openConversation(conversations[conversations.length-1].id)}

document.addEventListener('keydown',e=>{if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==='k'){e.preventDefault();newConversation()}if(e.key==='Escape'){$('#modeMenu').classList.add('hidden');closeSidebar()}});
document.addEventListener('click',e=>{if(!e.target.closest('.mode-wrap'))$('#modeMenu').classList.add('hidden')});
matchMedia('(prefers-color-scheme: dark)').addEventListener('change',()=>{if(prefs.theme==='system')setTheme('system')});
