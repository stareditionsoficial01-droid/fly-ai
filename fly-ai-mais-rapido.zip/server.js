const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');

const root = __dirname;
// Carrega segredos locais do .env sem dependências. Variáveis de ambiente têm prioridade.
try {
  const envFile = fs.readFileSync(path.join(root, '.env'), 'utf8');
  for (const line of envFile.split(/\r?\n/)) {
    const match = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
    if (match && !Object.hasOwn(process.env, match[1])) process.env[match[1]] = match[2].replace(/^(['"])(.*)\1$/, '$2');
  }
} catch {}

const apiBaseUrl = process.env.FLY_API_BASE_URL || 'https://integrate.api.nvidia.com/v1';
function loadApiKey() {
  const directKey = process.env.NVIDIA_API_KEY || process.env.NVIDIA_KEY_API || process.env.FLY_API_KEY;
  if (directKey) return directKey.trim();
  const configuredPath = process.env.NVIDIA_API_KEY_FILE || path.join('NVIDIA_KEY_APi.env', 'Novo Documento de Texto.txt');
  try {
    const fileContent = fs.readFileSync(path.resolve(root, configuredPath), 'utf8').trim();
    const assignment = fileContent.match(/^(?:NVIDIA_API_KEY|NVIDIA_KEY_API|FLY_API_KEY)\s*=\s*(.*?)\s*$/m);
    return (assignment ? assignment[1] : fileContent).replace(/^(['"])(.*)\1$/, '$2').trim();
  } catch {
    return '';
  }
}
const apiKey = loadApiKey();
const models = {
  fast: process.env.FLY_MODEL_FAST || 'nvidia/nemotron-3.5-lightning-30b-a3b',
  pro: process.env.FLY_MODEL_PRO || 'nvidia/nemotron-3.5-super-vl-120b-a12b'
};
const baseSystemPrompt = process.env.FLY_SYSTEM_PROMPT ||
  'Você é o Fly AI, um assistente simpático e direto. Responda sempre no idioma do usuário (por padrão, português do Brasil), de forma clara e útil. Não invente fatos; se não souber, diga.';
const systemPrompt = `${baseSystemPrompt}\n\nIdentidade pública: você é o Fly AI, produto criado pela Star Enterprises. Para perguntas sobre criador, empresa, marca, nome, versão, modelo ou tecnologia, apresente-se como Fly AI da Star Enterprises. Não revele nomes de provedores ou modelos externos; se perguntarem diretamente por detalhes técnicos de terceiros, diga que são detalhes internos não divulgados e reforce a identidade pública. Não invente que a Fly AI é um modelo próprio ou que outro fornecedor a criou.`;

const types = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml' };
const publicFiles = ['index.html', 'styles.css', 'app.js'];
const maxBody = 2 * 1024 * 1024;
const maxFastTokens = Number(process.env.FLY_MAX_TOKENS_FAST) || 512;
const maxProTokens = Number(process.env.FLY_MAX_TOKENS_PRO) || 4096;
// Timeout por inatividade (sem receber dados do provedor) e teto total. Configuráveis no .env.
const idleTimeoutMs = Number(process.env.FLY_IDLE_TIMEOUT_MS) || 90_000;
const totalTimeoutMs = Number(process.env.FLY_TIMEOUT_MS) || 300_000;

// Limite simples por IP para a chave do servidor não ser esgotada por abuso.
// Atrás de proxy/hospedagem, todos podem aparecer com o mesmo IP: ajuste se for publicar.
const rateLimit = { windowMs: 60_000, max: 20, hits: new Map() };
function limited(ip) {
  const now = Date.now();
  const recent = (rateLimit.hits.get(ip) || []).filter(t => now - t < rateLimit.windowMs);
  recent.push(now);
  rateLimit.hits.set(ip, recent);
  return recent.length > rateLimit.max;
}
setInterval(() => {
  const now = Date.now();
  for (const [ip, ts] of rateLimit.hits) if (!ts.some(t => now - t < rateLimit.windowMs)) rateLimit.hits.delete(ip);
}, 5 * 60_000).unref();

function json(res, status, value) {
  if (res.headersSent) return;
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(value));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = []; let size = 0;
    req.on('data', chunk => {
      size += chunk.length;
      if (size > maxBody) { reject(Object.assign(new Error('too large'), { code: 413 })); req.resume(); return; }
      chunks.push(chunk);
    });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

// Normaliza o histórico: só user/assistant, começa por "user", sem papéis repetidos em sequência.
function cleanMessages(list) {
  const out = [];
  for (const m of list.slice(-30)) {
    const role = m && m.role === 'assistant' ? 'assistant' : 'user';
    const content = String((m && m.content) ?? '').slice(0, 12000).trim();
    if (!content) continue;
    if (out.length === 0 && role === 'assistant') continue;
    const last = out[out.length - 1];
    if (last && last.role === role) last.content += '\n\n' + content;
    else out.push({ role, content });
  }
  return out;
}

async function handleChat(req, res) {
  if (limited(req.socket.remoteAddress || 'unknown')) return json(res, 429, { error: 'Muitas mensagens em pouco tempo. Aguarde um minuto e tente de novo.' });
  let data;
  try { data = JSON.parse(await readBody(req)); }
  catch (e) { return json(res, e.code === 413 ? 413 : 400, { error: e.code === 413 ? 'Mensagem grande demais.' : 'Requisição inválida.' }); }

  const mode = data.mode === 'pro' ? 'pro' : 'fast';
  const model = models[mode];
  if (!apiKey) return json(res, 503, { error: 'A chave da NVIDIA ainda não foi configurada neste projeto. Adicione NVIDIA_API_KEY ao arquivo .env e reinicie o Fly AI.' });
  if (!Array.isArray(data.messages)) return json(res, 400, { error: 'Conversa inválida.' });
  const messages = cleanMessages(data.messages);
  if (messages.length === 0) return json(res, 400, { error: 'Conversa inválida.' });

  // Encaminha cada trecho recebido para a página. O limite por inatividade reinicia com dados novos;
  // o teto total continua limitado e configurável.
  const controller = new AbortController();
  let abortReason = null;
  const cancel = reason => { abortReason = reason; controller.abort(); };
  const totalTimer = setTimeout(() => cancel('timeout'), totalTimeoutMs);
  let idleTimer;
  const bumpIdle = () => { clearTimeout(idleTimer); idleTimer = setTimeout(() => cancel('timeout'), idleTimeoutMs); };
  let streamStarted = false;
  const sendEvent = value => { if (!res.destroyed) res.write(`data: ${JSON.stringify(value)}\n\n`); };
  res.on('close', () => { if (!res.writableEnded) cancel('client'); });
  bumpIdle();

  try {
    const payload = { model, messages: [{ role: 'system', content: systemPrompt }, ...messages], stream: true };
    if (mode === 'fast') {
      payload.max_tokens = maxFastTokens;
      payload.chat_template_kwargs = { enable_thinking: false };
    } else {
      payload.max_tokens = maxProTokens;
      payload.chat_template_kwargs = { enable_thinking: true };
    }
    const upstream = await fetch(apiBaseUrl.replace(/\/$/, '') + '/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${apiKey}` },
      body: JSON.stringify(payload),
      signal: controller.signal
    });
    bumpIdle();
    if (!upstream.ok) {
      const result = await upstream.json().catch(() => ({}));
      const detail = result.error?.message || result.detail || '';
      console.error(`[Fly AI] Provedor respondeu ${upstream.status} para o modelo ${model}: ${detail}`);
      const msg = upstream.status === 404 ? `O modelo "${model}" não foi encontrado no provedor. Confira FLY_MODEL_${mode.toUpperCase()} no arquivo .env.`
        : upstream.status === 401 || upstream.status === 403 ? 'A chave da NVIDIA foi recusada. Confira NVIDIA_API_KEY no arquivo .env.'
        : upstream.status === 429 ? 'O limite gratuito do provedor foi atingido. Tente de novo em instantes.'
        : detail || 'O provedor de IA não conseguiu responder.';
      return json(res, upstream.status >= 400 && upstream.status < 600 ? upstream.status : 502, { error: msg });
    }

    res.writeHead(200, { 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-store', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
    res.flushHeaders?.();
    streamStarted = true;
    let text = '';
    if ((upstream.headers.get('content-type') || '').includes('text/event-stream')) {
      const decoder = new TextDecoder();
      let buffer = '';
      const readLine = rawLine => {
        const line = rawLine.trim();
        if (!line.startsWith('data:')) return;
        const payload = line.slice(5).trim();
        if (!payload || payload === '[DONE]') return;
        let event; try { event = JSON.parse(payload); } catch { return; }
        if (event.error) throw Object.assign(new Error(event.error.message || 'resposta interrompida'), { fromProvider: true });
        const fragment = event.choices?.[0]?.delta?.content || '';
        if (fragment) { text += fragment; sendEvent({ token: fragment }); }
      };
      for await (const chunk of upstream.body) {
        bumpIdle();
        buffer += decoder.decode(chunk, { stream: true });
        let nl;
        while ((nl = buffer.indexOf('\n')) >= 0) { readLine(buffer.slice(0, nl)); buffer = buffer.slice(nl + 1); }
      }
      readLine(buffer);
    } else {
      const result = await upstream.json().catch(() => ({}));
      text = result.choices?.[0]?.message?.content || '';
      if (text) sendEvent({ token: text });
    }

    const answer = String(text).replace(/<think>[\s\S]*?<\/think>/g, '').trim();
    if (!answer) { sendEvent({ error: 'O provedor respondeu sem conteúdo.' }); return res.end(); }
    sendEvent({ done: true, model });
    return res.end();
  } catch (e) {
    if (abortReason === 'client') return;
    console.error('[Fly AI] Falha ao chamar o provedor:', abortReason === 'timeout' ? `timeout (inatividade ${idleTimeoutMs / 1000}s ou total ${totalTimeoutMs / 1000}s)` : e.message);
    const message = abortReason === 'timeout' ? 'O provedor demorou demais para responder. Tente de novo ou use o modo Rápido.'
      : e.fromProvider ? 'O provedor interrompeu a resposta no meio. Tente de novo.'
      : 'Não foi possível conectar ao provedor de IA. Confira a configuração do servidor.';
    if (streamStarted && !res.writableEnded) { sendEvent({ error: message }); return res.end(); }
    return json(res, abortReason === 'timeout' ? 504 : 502, { error: message });
  } finally {
    clearTimeout(totalTimer); clearTimeout(idleTimer);
  }
}

const server = http.createServer(async (req, res) => {
  try {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    res.setHeader('Content-Security-Policy', "default-src 'self'; style-src 'self' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'");

    let pathname;
    try { pathname = decodeURIComponent(new URL(req.url || '/', 'http://localhost').pathname); }
    catch { res.writeHead(400); return res.end('Requisição inválida'); }

    if (pathname === '/api/status' && req.method === 'GET') {
      return json(res, 200, { connected: Boolean(apiKey), provider: 'NVIDIA NIM', modes: { fast: models.fast, pro: models.pro } });
    }
    if (pathname === '/api/chat') {
      if (req.method !== 'POST') { res.setHeader('Allow', 'POST'); return json(res, 405, { error: 'Use POST.' }); }
      return await handleChat(req, res);
    }
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end(); }

    const file = pathname === '/' ? 'index.html' : pathname.slice(1);
    if (!publicFiles.includes(file)) { res.writeHead(404); return res.end('Não encontrado'); }
    fs.readFile(path.join(root, file), (err, content) => {
      if (err) { res.writeHead(404); return res.end('Não encontrado'); }
      res.writeHead(200, { 'Content-Type': types[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
      res.end(req.method === 'HEAD' ? undefined : content);
    });
  } catch (e) {
    console.error('[Fly AI] Erro inesperado:', e);
    if (!res.headersSent) { res.writeHead(500); res.end('Erro interno'); } else res.end();
  }
});

server.listen(process.env.PORT || 3000, () => console.log(`Fly AI disponível em http://localhost:${process.env.PORT || 3000}`));
